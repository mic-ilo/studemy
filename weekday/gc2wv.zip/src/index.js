import showWeekday from "./show-weekday";

showWeekday();

const rootElement = document.getElementById("root");
rootElement.innerHTML = "Hello world";
